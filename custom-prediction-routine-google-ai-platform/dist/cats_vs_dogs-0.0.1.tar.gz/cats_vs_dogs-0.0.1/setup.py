# setup script
from setuptools import setup
setup (
  name ='cats_vs_dogs',
  version='0.0.1',
  include_package_data=False,
  scripts=['prediction.py']
)
